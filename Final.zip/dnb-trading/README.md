# DNB Trading & Enterprises — Corporate Website

Built to the master specification: verified numbers only (55+ tender
participation, 12+ contracts awarded), one verified project reference
(Kathmandu University smart classroom implementation), no invented claims,
no stock photography of people.

## Structure

```
dnb-trading/
├── index.html
├── css/style.css
├── js/script.js
└── assets/
    ├── images/   <- add favicon.png and logo.png here
    └── icons/
```

Plain HTML/CSS/JS — no build step, no framework.

## Brand colors (all in `css/style.css` under `:root`)

| Name        | Hex       |
|-------------|-----------|
| Dark Navy   | `#0B1F33` |
| Steel Blue  | `#245B85` |
| Gold        | `#C89B3C` |
| White       | `#FFFFFF` |
| Light       | `#F5F7FA` |

## What was deliberately left out (per your "no fake claims" rule)

- No client logos, testimonials, or awards — none were provided.
- No stock photography of people/handshakes — the design relies on
  typography, a technical grid pattern in the hero, and numbered
  index cards instead.
- Project section only lists the one verified project (Kathmandu
  University) plus a neutral "Institutional Supply Projects" entry for
  everything else, exactly as specified.
- Experience numbers are exactly 55+ and 12+ — nothing rounded up or
  dramatized.

## Before going live

1. **Logo.** Swap the text-based "DNB" mark (`.logo-mark` in `index.html`,
   appears in the header and footer) for `assets/images/logo.png` once you
   have an exported file.
2. **Favicon.** Add `assets/images/favicon.png` — already linked in `<head>`.
3. **Contact form.** `js/script.js` validates the fields but doesn't send
   email — there's no backend. Fastest fix: sign up for a free form
   service like [Formspree](https://formspree.io) or
   [Web3Forms](https://web3forms.com) and point the form at it, or wire it
   to your own backend/email API.
4. **Phone number.** Add one to the Contact section if you want it listed
   — it wasn't in the provided company information, so it's omitted for now.
5. **Images.** If you'd like real photography later (equipment, warehouse,
   site work), send the actual photos and I'll place them — per the spec,
   no generic/AI stock photos were used as placeholders.

## Deploying

No build step, so any static host works:

- **GitHub Pages:** push this folder to a repo, enable Pages pointing at
  the repo root.
- **Cloudflare Pages:** connect the repo, framework preset "None," empty
  build command, output directory `/`.
